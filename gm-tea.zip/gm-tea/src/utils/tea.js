import { ethers } from 'ethers';

const CONTRACT_ADDRESS = '0xEF7E119Fe7c0d2c0252a2e47E0c7FBc3FE1D4a'; // GM contract
const ABI = [
  "function gm() public"
];

export const sendGM = async () => {
  if (!window.ethereum) throw new Error("No wallet detected");
  const provider = new ethers.BrowserProvider(window.ethereum);
  const signer = await provider.getSigner();
  const contract = new ethers.Contract(CONTRACT_ADDRESS, ABI, signer);
  const tx = await contract.gm({ gasLimit: 100000 });
  await tx.wait();
};
