import { useState } from 'react';
import { sendGM } from './utils/tea';

function App() {
  const [status, setStatus] = useState('');

  const handleGM = async () => {
    setStatus('Sending GM...');
    try {
      await sendGM();
      setStatus('GM sent successfully 🌞');
    } catch (err) {
      setStatus('Error sending GM 😢');
    }
  };

  return (
    <div className="flex flex-col items-center justify-center h-screen gap-4 bg-gradient-to-br from-yellow-100 to-pink-100">
      <h1 className="text-4xl font-bold">GM TEA ☕</h1>
      <button
        onClick={handleGM}
        className="px-6 py-3 bg-emerald-500 text-white rounded-full hover:bg-emerald-600 transition"
      >
        GM
      </button>
      <p className="text-lg text-gray-700">{status}</p>
    </div>
  );
}

export default App;
