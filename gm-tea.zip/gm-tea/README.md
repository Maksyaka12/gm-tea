# GM TEA ☕

Send GM on Tea Testnet with one click.

## Usage

1. Connect MetaMask
2. Click "GM"
3. Done — you're on-chain GMing 🍵

## Built with

- React + Vite
- ethers.js
- Tea Testnet

## Contract

0xEF7E119Fe7c0d2c0252a2e47E0c7FBc3FE1D4a
